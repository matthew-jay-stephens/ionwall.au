IONWALL SECURITY - SITE FILES

Upload everything in this folder to your Cloudflare Pages project (keep the folder structure).

SENDING QUOTE REQUESTS TO admin@ionwallsecurity.com.au
The quote form posts to functions/api/quote.js, which emails the request (with the marked-up plan attached) via Resend.
1. Create a free account at resend.com and add/verify the domain ionwallsecurity.com.au (Resend shows the DNS records to add).
2. Create an API key in Resend.
3. In Cloudflare: Workers & Pages > your project > Settings > Variables and Secrets > add a secret named RESEND_API_KEY.
4. Deploy with the "functions" folder included. Cloudflare Pages Functions are built from Git deployments or "wrangler pages deploy"; a plain drag-and-drop upload may not include them.
Optional variables: QUOTE_TO (default admin@ionwallsecurity.com.au), QUOTE_FROM (default quotes@ionwallsecurity.com.au - must be on the verified domain).
Until this is set up, the form opens the customer's email app addressed to admin@ instead.

BEFORE YOU WANT BUSINESS FROM THE SITE
Delete the <meta name="robots" content="noindex, nofollow"> line from every .html page so Google can list it.
