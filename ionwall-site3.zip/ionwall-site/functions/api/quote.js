// Cloudflare Pages Function: receives the quote form and emails it to admin@ via Resend.
// Needs a secret named RESEND_API_KEY (Pages > Settings > Variables and Secrets).
// Optional variables: QUOTE_TO, QUOTE_FROM.

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

export async function onRequestPost({ request, env }) {
  if (!env.RESEND_API_KEY) return json({ error: "Email sending is not configured." }, 503);

  let fd;
  try { fd = await request.formData(); } catch (_) { return json({ error: "Bad request." }, 400); }

  const field = (k, max = 300) => String(fd.get(k) || "").replace(/\r/g, "").trim().slice(0, max);
  const oneLine = (s) => s.replace(/\s+/g, " ");
  const name = oneLine(field("name")), email = oneLine(field("email"));
  const phone = oneLine(field("phone")), address = oneLine(field("address"));
  const message = field("message", 4000), planSummary = field("plan_summary", 4000);

  if (!name || !address || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return json({ error: "Name, email and address are required." }, 400);
  }

  const attachments = [];
  const plan = fd.get("plan");
  if (plan && typeof plan === "object" && plan.size) {
    if (plan.size > 8 * 1024 * 1024) return json({ error: "Plan image is too large." }, 413);
    const bytes = new Uint8Array(await plan.arrayBuffer());
    let bin = "";
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    attachments.push({ filename: "ionwall-plan.png", content: btoa(bin) });
  }

  const text = [
    "New quote request from the website", "",
    "Name: " + name, "Phone: " + (phone || "-"), "Email: " + email, "Site address: " + address, "",
    "Message:", message || "-", "", "Plan details:", planSummary || "No plan attached."
  ].join("\n");

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: "Bearer " + env.RESEND_API_KEY, "content-type": "application/json" },
    body: JSON.stringify({
      from: env.QUOTE_FROM || "Ionwall Security <quotes@ionwallsecurity.com.au>",
      to: [env.QUOTE_TO || "admin@ionwallsecurity.com.au"],
      reply_to: email,
      subject: "Quote request - " + name,
      text,
      attachments
    })
  });
  if (!res.ok) return json({ error: "Could not send the email." }, 502);
  return json({ ok: true });
}
