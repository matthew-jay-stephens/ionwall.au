(() => {
  "use strict";

  // Requests are posted here (functions/api/quote.js emails them to admin@ with the plan attached).
  // If that isn't set up yet, or fails, the form falls back to opening the customer's email app.
  const FORM_ENDPOINT = "/api/quote";

  const TYPES = {
    camera:   { label: "Camera",         short: "C", color: "#e4572e", fov: true, angle: 90, range: 0.22 },
    sensor:   { label: "Motion sensor",  short: "M", color: "#1b998b", fov: true, angle: 90, range: 0.10 },
    reader:   { label: "Access reader",  short: "R", color: "#7b4fd1" },
    intercom: { label: "Intercom",       short: "I", color: "#d98e00" },
    keypad:   { label: "Alarm keypad",   short: "K", color: "#2d6cdf" },
    siren:    { label: "Siren",          short: "S", color: "#c1121f" },
    data:     { label: "Data point",     short: "D", color: "#5c677d" }
  };
  const FONT = "system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif";

  const $ = (id) => document.getElementById(id);
  const canvas = $("plan");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  let base = null, devices = [], sel = null, tool = "select";
  let ppm = null, scalePts = [], pendingScale = null, drag = null, nextId = 1, k = 1, dpr = 1;

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const getSel = () => devices.find((d) => d.id === sel) || null;
  const compass = (deg) => ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(deg / 45) % 8];
  const hexA = (h, a) => { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
  const say = (t) => { $("status").textContent = t; };

  // ---------- loading ----------
  function loadPlan(file) {
    if (!file || !file.type.startsWith("image/")) {
      say("Please choose an image file (JPG, PNG or WebP). For a PDF, export or screenshot the page as an image first.");
      return;
    }
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const s = Math.min(1, 2400 / Math.max(im.naturalWidth, im.naturalHeight));
      base = document.createElement("canvas");
      base.width = Math.round(im.naturalWidth * s);
      base.height = Math.round(im.naturalHeight * s);
      const b = base.getContext("2d");
      b.fillStyle = "#fff"; b.fillRect(0, 0, base.width, base.height);
      b.drawImage(im, 0, 0, base.width, base.height);
      URL.revokeObjectURL(url);
      devices = []; sel = null; ppm = null; scalePts = []; tool = "select";
      $("plannerUI").hidden = false; $("drop").hidden = true;
      say("");
      layout(); syncToolbar(); syncPanel(); updateSummary();
    };
    im.onerror = () => say("That file couldn't be read as an image. Please try another.");
    im.src = url;
  }

  // ---------- drawing ----------
  function layout() {
    if (!base) return;
    const W = canvas.parentElement.clientWidth;
    if (!W) return;
    k = W / base.width; dpr = window.devicePixelRatio || 1;
    canvas.style.width = W + "px";
    canvas.style.height = Math.round(base.height * k) + "px";
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(base.height * k * dpr);
    render();
  }
  function render() {
    if (!base) return;
    ctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    paint(ctx, 1 / k, true);
  }
  function handlePos(d) {
    const a = (d.dir - 90) * Math.PI / 180;
    return { x: d.x + d.range * Math.cos(a), y: d.y + d.range * Math.sin(a) };
  }
  function paint(c, u, ui) {
    c.clearRect(0, 0, base.width, base.height);
    c.drawImage(base, 0, 0);
    if (ui && scalePts.length) {
      c.strokeStyle = "#d00000"; c.fillStyle = "#d00000"; c.lineWidth = 2 * u;
      scalePts.forEach((p) => { c.beginPath(); c.arc(p.x, p.y, 5 * u, 0, 7); c.fill(); });
      if (scalePts.length === 2) { c.beginPath(); c.moveTo(scalePts[0].x, scalePts[0].y); c.lineTo(scalePts[1].x, scalePts[1].y); c.stroke(); }
    }
    devices.forEach((d, i) => drawDevice(c, d, i, u, ui && d.id === sel));
  }
  function drawDevice(c, d, i, u, selected) {
    const T = TYPES[d.type];
    if (T.fov) {
      const a = (d.dir - 90) * Math.PI / 180, half = d.angle * Math.PI / 360;
      c.beginPath();
      if (d.angle >= 360) c.arc(d.x, d.y, d.range, 0, Math.PI * 2);
      else { c.moveTo(d.x, d.y); c.arc(d.x, d.y, d.range, a - half, a + half); c.closePath(); }
      c.fillStyle = hexA(T.color, 0.22); c.fill();
      c.strokeStyle = hexA(T.color, 0.85); c.lineWidth = 1.5 * u; c.stroke();
      if (selected) {
        const h = handlePos(d);
        c.setLineDash([5 * u, 4 * u]); c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(h.x, h.y); c.stroke(); c.setLineDash([]);
        c.beginPath(); c.arc(h.x, h.y, 8 * u, 0, 7); c.fillStyle = "#fff"; c.fill(); c.lineWidth = 2.5 * u; c.strokeStyle = T.color; c.stroke();
      }
    }
    c.beginPath(); c.arc(d.x, d.y, 12 * u, 0, 7);
    c.fillStyle = T.color; c.fill(); c.lineWidth = 2.5 * u; c.strokeStyle = "#fff"; c.stroke();
    c.fillStyle = "#fff"; c.font = `700 ${12 * u}px ${FONT}`; c.textAlign = "center"; c.textBaseline = "middle";
    c.fillText(T.short, d.x, d.y + 0.5 * u);
    c.beginPath(); c.arc(d.x + 11 * u, d.y - 11 * u, 7 * u, 0, 7); c.fillStyle = "#1c2431"; c.fill();
    c.fillStyle = "#fff"; c.font = `700 ${9 * u}px ${FONT}`; c.fillText(String(i + 1), d.x + 11 * u, d.y - 10.5 * u);
    if (d.label) {
      c.font = `600 ${11 * u}px ${FONT}`; c.textAlign = "left";
      c.lineWidth = 3.5 * u; c.strokeStyle = "rgba(255,255,255,.95)"; c.strokeText(d.label, d.x + 17 * u, d.y + 5 * u);
      c.fillStyle = "#1c2431"; c.fillText(d.label, d.x + 17 * u, d.y + 5 * u);
    }
    if (selected) {
      c.setLineDash([4 * u, 3 * u]); c.beginPath(); c.arc(d.x, d.y, 18 * u, 0, 7);
      c.lineWidth = 1.5 * u; c.strokeStyle = "#1c2431"; c.stroke(); c.setLineDash([]);
    }
  }
  function drawLegend(c, u) {
    const used = [...new Set(devices.map((d) => d.type))];
    if (!used.length) return;
    c.font = `600 ${12 * u}px ${FONT}`;
    const lh = 20 * u, pad = 10 * u;
    const w = Math.max(...used.map((t) => c.measureText(TYPES[t].label).width)) + 24 * u + pad * 2;
    const h = lh * used.length + pad * 2, x = 10 * u, y = base.height - h - 10 * u;
    c.fillStyle = "rgba(255,255,255,.93)"; c.fillRect(x, y, w, h);
    c.strokeStyle = "#999"; c.lineWidth = u; c.strokeRect(x, y, w, h);
    used.forEach((t, i) => {
      const cy = y + pad + lh * i + lh / 2;
      c.fillStyle = TYPES[t].color; c.beginPath(); c.arc(x + pad + 7 * u, cy, 7 * u, 0, 7); c.fill();
      c.fillStyle = "#1c2431"; c.textAlign = "left"; c.textBaseline = "middle"; c.fillText(TYPES[t].label, x + pad + 22 * u, cy);
    });
  }
  function exportBlob() {
    return new Promise((res) => {
      const c = document.createElement("canvas"); c.width = base.width; c.height = base.height;
      const cx = c.getContext("2d"), u = 1 / k;
      paint(cx, u, false); drawLegend(cx, u);
      c.toBlob(res, "image/png");
    });
  }

  // ---------- interaction ----------
  const pos = (e) => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) / k, y: (e.clientY - r.top) / k }; };

  canvas.addEventListener("pointerdown", (e) => {
    if (!base) return;
    const p = pos(e), u = 1 / k;
    if (tool === "scale") {
      if (scalePts.length >= 2) scalePts = [];
      scalePts.push(p);
      if (scalePts.length === 2) { pendingScale = Math.hypot(scalePts[1].x - scalePts[0].x, scalePts[1].y - scalePts[0].y); $("scaleForm").hidden = false; $("scaleM").focus(); }
      syncToolbar(); render(); return;
    }
    if (tool !== "select") {
      const T = TYPES[tool];
      const d = { id: nextId++, type: tool, x: p.x, y: p.y, label: "", dir: 0, angle: T.angle || 0, range: (T.range || 0) * base.width };
      devices.push(d); sel = d.id; tool = "select";
      syncToolbar(); syncPanel(); updateSummary(); render(); return;
    }
    const s = getSel();
    if (s && TYPES[s.type].fov) {
      const h = handlePos(s);
      if (Math.hypot(p.x - h.x, p.y - h.y) <= 16 * u) { drag = { mode: "handle" }; canvas.setPointerCapture(e.pointerId); return; }
    }
    for (let i = devices.length - 1; i >= 0; i--) {
      const d = devices[i];
      if (Math.hypot(p.x - d.x, p.y - d.y) <= 18 * u) {
        sel = d.id; drag = { mode: "move", ox: p.x - d.x, oy: p.y - d.y };
        canvas.setPointerCapture(e.pointerId); syncPanel(); render(); return;
      }
    }
    sel = null; syncPanel(); render();
  });
  canvas.addEventListener("pointermove", (e) => {
    const d = getSel();
    if (!drag || !d) return;
    const p = pos(e);
    if (drag.mode === "move") { d.x = clamp(p.x - drag.ox, 0, base.width); d.y = clamp(p.y - drag.oy, 0, base.height); }
    else {
      const dx = p.x - d.x, dy = p.y - d.y;
      d.dir = Math.round(((Math.atan2(dy, dx) * 180 / Math.PI + 90) + 360) % 360) % 360;
      d.range = clamp(Math.hypot(dx, dy), 15 / k, Math.hypot(base.width, base.height));
      syncPanel(true);
    }
    render();
  });
  const endDrag = () => { if (drag) { drag = null; updateSummary(); } };
  canvas.addEventListener("pointerup", endDrag);
  canvas.addEventListener("pointercancel", endDrag);

  document.addEventListener("keydown", (e) => {
    const typing = /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || "");
    if (e.key === "Escape") { tool = "select"; scalePts = []; $("scaleForm").hidden = true; syncToolbar(); render(); }
    if ((e.key === "Delete" || e.key === "Backspace") && sel && !typing && base) { e.preventDefault(); removeSel(); }
  });
  function removeSel() { devices = devices.filter((d) => d.id !== sel); sel = null; syncPanel(); updateSummary(); render(); }

  // ---------- toolbar / panel ----------
  const tb = $("toolbar");
  function btn(id, label, color) {
    const b = document.createElement("button");
    b.type = "button"; b.dataset.tool = id;
    b.innerHTML = (color ? `<i style="background:${color}"></i>` : "") + label;
    b.addEventListener("click", () => {
      tool = tool === id && id !== "select" ? "select" : id;
      if (tool !== "scale") { scalePts = []; $("scaleForm").hidden = true; }
      syncToolbar(); render();
    });
    tb.appendChild(b);
  }
  btn("select", "Select / move");
  Object.entries(TYPES).forEach(([id, t]) => btn(id, t.label, t.color));
  btn("scale", "Set scale");
  function syncToolbar() {
    tb.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.tool === tool)));
    canvas.style.cursor = tool === "select" ? "default" : "crosshair";
    $("hint").textContent =
      tool === "scale" ? (scalePts.length === 1 ? "Now click the other end of something you know the length of." : "Click one end of something you know the length of, such as a wall or door.")
      : tool !== "select" ? "Click on the plan to place a " + TYPES[tool].label.toLowerCase() + "."
      : sel ? "Drag the device to move it. Drag the round handle on its view cone to aim it and set how far it sees."
      : "Choose a device above, then click the plan to place it.";
    $("scaleNote").textContent = ppm ? "Scale set." : "Optional: set the scale so ranges show in metres.";
  }
  $("scaleApply").addEventListener("click", () => {
    const m = parseFloat($("scaleM").value);
    if (!(m > 0) || !pendingScale) return;
    ppm = pendingScale / m; scalePts = []; $("scaleForm").hidden = true; $("scaleM").value = "";
    tool = "select"; syncToolbar(); syncPanel(); updateSummary(); render();
  });
  $("scaleM").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); $("scaleApply").click(); } });

  const fmtRange = (d) => ppm ? (d.range / ppm).toFixed(1) + " m" : Math.round(d.range / base.width * 100) + "% of plan width";
  function syncPanel(skipLabel) {
    const d = getSel(); $("inspector").hidden = !d; $("inspectorEmpty").hidden = !!d;
    syncToolbar();
    if (!d) return;
    const T = TYPES[d.type];
    $("pTitle").textContent = (devices.indexOf(d) + 1) + ". " + T.label;
    if (!skipLabel) $("pLabel").value = d.label;
    $("pFov").hidden = !T.fov;
    if (T.fov) {
      $("pDir").value = d.dir; $("pDirO").textContent = d.dir + "° (" + compass(d.dir) + ")";
      $("pAngle").value = d.angle; $("pAngleO").textContent = d.angle >= 360 ? "360°" : d.angle + "°";
      $("pRange").max = Math.round(Math.hypot(base.width, base.height)); $("pRange").value = Math.round(d.range); $("pRangeO").textContent = fmtRange(d);
    }
  }
  $("pLabel").addEventListener("input", (e) => { const d = getSel(); if (d) { d.label = e.target.value.slice(0, 40); updateSummary(); render(); } });
  [["pDir", "dir"], ["pAngle", "angle"], ["pRange", "range"]].forEach(([id, key]) =>
    $(id).addEventListener("input", (e) => { const d = getSel(); if (d) { d[key] = Number(e.target.value); syncPanel(true); updateSummary(); render(); } }));
  $("pDelete").addEventListener("click", removeSel);
  $("clearAll").addEventListener("click", () => { if (devices.length && !confirm("Remove all devices from the plan?")) return; devices = []; sel = null; syncPanel(); updateSummary(); render(); });
  $("changePlan").addEventListener("click", () => { $("planFile").value = ""; $("planFile").click(); });

  // ---------- upload ----------
  $("planFile").addEventListener("change", (e) => loadPlan(e.target.files[0]));
  const drop = $("drop");
  ["dragenter", "dragover"].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", (e) => loadPlan(e.dataTransfer.files[0]));

  if (window.ResizeObserver) new ResizeObserver(layout).observe(canvas.parentElement);
  window.addEventListener("resize", layout);

  // ---------- summary + sending ----------
  function summary() {
    const counts = {}; devices.forEach((d) => { counts[d.type] = (counts[d.type] || 0) + 1; });
    const lines = ["Devices marked on plan: " + (devices.length ? Object.entries(counts).map(([t, n]) => n + " x " + TYPES[t].label).join(", ") : "none")];
    devices.forEach((d, i) => {
      const T = TYPES[d.type]; let s = (i + 1) + ". " + T.label + (d.label ? " - " + d.label : "");
      if (T.fov) s += " (" + (d.angle >= 360 ? "360° view" : d.angle + "° view") + ", facing " + compass(d.dir) + ", range " + fmtRange(d) + ")";
      lines.push(s);
    });
    return lines.join("\n");
  }
  function updateSummary() { $("summary").textContent = base ? summary() : ""; $("summaryBox").hidden = !base; }

  async function download(blob) {
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "ionwall-plan.png";
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  $("downloadPlan").addEventListener("click", async () => { if (base) download(await exportBlob()); });

  $("quoteForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, v = (n) => f.elements[n].value.trim();
    if (v("company")) return; // honeypot
    for (const [n, what] of [["name", "your name"], ["email", "your email address"], ["address", "the site address"]]) {
      if (!v(n)) { say("Please enter " + what + "."); f.elements[n].focus(); return; }
    }
    const details = ["Name: " + v("name"), "Phone: " + v("phone"), "Email: " + v("email"), "Site address / suburb: " + v("address"), "", v("message"), "", base ? summary() : "No plan attached."].join("\n");
    const blob = base ? await exportBlob() : null;
    let sentDirect = false;
    if (FORM_ENDPOINT) {
      const fd = new FormData();
      ["name", "phone", "email", "address", "message"].forEach((n) => fd.append(n, v(n)));
      fd.append("plan_summary", base ? summary() : "");
      if (blob) fd.append("plan", blob, "ionwall-plan.png");
      try {
        const r = await fetch(FORM_ENDPOINT, { method: "POST", body: fd, headers: { Accept: "application/json" } });
        sentDirect = r.ok;
      } catch (_) { sentDirect = false; }
      if (sentDirect) { say("Thanks, your request has been sent. We'll be in touch soon."); f.reset(); return; }
    }
    if (blob) download(blob);
    const body = encodeURIComponent(details).slice(0, 1800).replace(/%[0-9A-F]?$/, "");
    window.location.href = "mailto:admin@ionwallsecurity.com.au?subject=" + encodeURIComponent("Quote request" + (v("name") ? " - " + v("name") : "")) + "&body=" + body;
    say(blob ? "Your email app should open with your details. Please attach the file ionwall-plan.png that just downloaded, then send." : "Your email app should open with your details. Press send to finish.");
  });

  // ---------- address finder (OpenStreetMap data via Photon; no key needed) ----------
  (function () {
    const input = $("addr"), list = $("addrList");
    if (!input || !list) return;
    const PHOTON = "https://photon.komoot.io/api/";
    const STATES = { "New South Wales": "NSW", "Queensland": "QLD", "Victoria": "VIC", "South Australia": "SA", "Western Australia": "WA", "Tasmania": "TAS", "Northern Territory": "NT", "Australian Capital Territory": "ACT" };
    let items = [], active = -1, timer = null, ctl = null, last = "";
    const close = () => { list.hidden = true; input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant"); active = -1; };
    const label = (p) => {
      const place = p.city || p.district || p.locality || p.county || "";
      let line1 = [p.housenumber, p.street || p.name].filter(Boolean).join(" ");
      if (line1 === place) line1 = "";
      const tail = [place, STATES[p.state] || p.state || "", p.postcode || ""].filter(Boolean).join(" ");
      return [line1, tail].filter(Boolean).join(", ");
    };
    function show() {
      list.innerHTML = "";
      if (!items.length) return close();
      items.forEach((t, i) => {
        const li = document.createElement("li");
        li.id = "addrOpt" + i; li.setAttribute("role", "option"); li.textContent = t;
        li.addEventListener("mousedown", (e) => { e.preventDefault(); pick(i); });
        list.appendChild(li);
      });
      list.hidden = false; input.setAttribute("aria-expanded", "true"); active = -1;
    }
    function mark(i) {
      active = i;
      [...list.children].forEach((li, n) => li.setAttribute("aria-selected", String(n === i)));
      if (i >= 0) { input.setAttribute("aria-activedescendant", "addrOpt" + i); list.children[i].scrollIntoView({ block: "nearest" }); }
    }
    function pick(i) { input.value = last = items[i]; close(); input.setCustomValidity(""); }
    async function search(q) {
      if (ctl) ctl.abort();
      ctl = new AbortController();
      // lat/lon gently favour the Hunter Valley; bbox limits results to Australia.
      const url = PHOTON + "?q=" + encodeURIComponent(q) + "&limit=10&lang=en&lat=-32.7&lon=151.5&bbox=112,-44,154,-9";
      try {
        const r = await fetch(url, { signal: ctl.signal });
        if (!r.ok) throw new Error("bad response");
        const data = await r.json(), seen = new Set(); items = [];
        for (const f of data.features || []) {
          const p = f.properties || {};
          if (p.countrycode && p.countrycode !== "AU") continue;
          const l = label(p);
          if (!l || seen.has(l)) continue;
          seen.add(l); items.push(l);
          if (items.length >= 6) break;
        }
        show();
      } catch (err) { if (err.name !== "AbortError") close(); } // on any failure, typing manually still works
    }
    input.addEventListener("input", () => {
      const q = input.value.trim();
      clearTimeout(timer);
      if (q.length < 4 || q === last) return close();
      timer = setTimeout(() => search(q), 300);
    });
    input.addEventListener("keydown", (e) => {
      if (list.hidden) return;
      if (e.key === "ArrowDown") { e.preventDefault(); mark((active + 1) % items.length); }
      else if (e.key === "ArrowUp") { e.preventDefault(); mark((active - 1 + items.length) % items.length); }
      else if (e.key === "Enter" && active >= 0) { e.preventDefault(); pick(active); }
      else if (e.key === "Escape") { e.stopPropagation(); close(); }
    });
    input.addEventListener("blur", () => setTimeout(close, 150));
  })();

  syncToolbar();
})();
